"""Export signed API sources and the reviewed lock seed for Cargo resolution."""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import tomllib


def git(repository, *arguments):
    return subprocess.check_output(["git", "-C", str(repository), *arguments])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("repository", type=Path)
    parser.add_argument("revision")
    parser.add_argument("destination", type=Path)
    parser.add_argument("--upstream", type=Path, required=True)
    parser.add_argument("--api-revision", default="c23dd00a342a98c2a7c9005f6712c9dcb608b69d")
    parser.add_argument("--lock-revision", default="bb763aa3b175b755c8b85c2115722d6ad749088b")
    parser.add_argument("--lock-path", default="Cargo.lock")
    parser.add_argument("--lock-sha256", default="1ecb41e738c4c4133a1968873e424efce5b2a65899dd8f40f37ac6aaffec8133")
    args = parser.parse_args()
    args.destination.mkdir(parents=True, exist_ok=False)
    revision = git(args.repository, "rev-parse", args.revision).decode().strip()
    base = "c23dd00a342a98c2a7c9005f6712c9dcb608b69d"
    api_revision = git(args.repository, "rev-parse", args.api_revision).decode().strip()
    seed = git(args.upstream, "rev-parse", args.lock_revision).decode().strip()
    git(args.repository, "merge-base", "--is-ancestor", base, revision)
    files = {}
    provenance = {}
    names = git(args.repository, "ls-tree", "-r", "--name-only", api_revision, "vendor/shards").decode().splitlines()
    for name in names:
        relative = str(Path(name).relative_to("vendor/shards"))
        data = git(args.repository, "show", api_revision + ":" + name)
        files[relative] = data
        provenance[relative] = {"revision": api_revision, "path": name, "sha256": sha(data)}
    owned = "crates/hex-cli/tests/completion_managed_api.rs"
    installed = "crates/api/tests/completion_managed_api.rs"
    files[installed] = git(args.repository, "show", revision + ":" + owned)
    provenance[installed] = {"revision": revision, "path": owned, "sha256": sha(files[installed])}
    lock = git(args.upstream, "show", seed + ":" + args.lock_path)
    if sha(lock) != args.lock_sha256:
        raise ValueError("upstream lock seed differs")
    registry = [row for row in tomllib.loads(lock.decode())["package"] if "source" in row]
    files["Cargo.lock"] = lock
    provenance["Cargo.lock"] = {
        "revision": seed,
        "path": args.lock_path,
        "seed_sha256": sha(lock),
        "sha256": sha(lock),
        "transform": "unchanged reviewed seed; Cargo resolves the private lock before compilation",
        "registry": registry,
    }
    manifest = {
        "source_revision": revision,
        "base_revision": base,
        "api_revision": api_revision,
        "policy_revision": "ca3ab10c151aa5539e757f1cc76029746ccbb561",
        "rules_sha256": "df2acf47cf92996e9435f9a4988f10e9e7aaa21ca952a00069c044c7ed4f13d3",
        "files": provenance,
    }
    files["CLOSURE.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w") as archive:
        for name, data in sorted(files.items()):
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            archive.addfile(entry, io.BytesIO(data))
    compressed = gzip.compress(raw.getvalue(), mtime=0)
    (args.destination / "source.tar.gz").write_bytes(compressed)
    (args.destination / "upstream-Cargo.lock").write_bytes(lock)
    (args.destination / "closure.json").write_text(json.dumps(manifest, indent=2) + "\n")
    receipt = {"revision": revision, "archive_sha256": sha(compressed), "bytes": len(compressed), "file_count": len(files)}
    (args.destination / "prepared.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
