"""Submit the owned API-only controls through the admitted d132 runner."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import uuid


REMOTE = r'''
import hashlib, io, json, os, platform, subprocess, sys, tarfile, tomllib
from pathlib import Path, PurePosixPath
root = Path(sys.argv[1])
expected, revision = sys.argv[2:4]
resuming = len(sys.argv) > 4 and sys.argv[4] == 'resume'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = root/'source'
if resuming:
    if sha(root/'source.tar.gz') != expected:
        raise ValueError('recorded archive mismatch')
    manifest = json.loads((root/'source-before.json').read_text())
else:
    # Exclusive creation fences delayed duplicates before any check effects.
    root.mkdir(parents=True, exist_ok=False)
    raw = sys.stdin.buffer.read()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('archive mismatch')
    (root/'source.tar.gz').write_bytes(raw)
    source.mkdir()
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        for member in archive.getmembers():
            name = PurePosixPath(member.name)
            if name.is_absolute() or '..' in name.parts or not (member.isfile() or member.isdir()):
                raise ValueError('invalid archive member')
        archive.extractall(source, filter='data')
    for name in ['target', 'cache/cargo', 'temp', 'run']:
        (root/name).mkdir(parents=True)
    manifest = {str(path.relative_to(source)): sha(path) for path in sorted(source.rglob('*')) if path.is_file()}
closure = json.loads((source/'CLOSURE.json').read_text())
if closure['source_revision'] != revision:
    raise ValueError('source revision mismatch')
for name, record in closure['files'].items():
    if manifest[name] != record['sha256']:
        raise ValueError('source differs from pinned closure: '+name)
registry = closure['files']['Cargo.lock']['registry']
if not resuming and registry != [row for row in tomllib.loads((source/'Cargo.lock').read_text())['package'] if 'source' in row]:
    raise ValueError('generated registry graph differs from pinned seed')
if not resuming:
    (root/'source-before.json').write_text(json.dumps(manifest, indent=2)+'\n')
rustup = Path('/Users/adalundhe/.cache/hex-lead/rustup-scheduler-copy')
toolchain = rustup/'toolchains/1.99.1-aarch64-apple-darwin/bin'
environment = {key: value for key, value in os.environ.items() if not key.startswith(('DYLD_', 'HEX_DEBUG_', 'SHARDS_DEBUG_'))}
environment.pop('CARGO_BUILD_TARGET', None)
environment.update(PATH=str(toolchain)+os.pathsep+environment['PATH'],
    RUSTUP_HOME=str(rustup), RUSTC=str(toolchain/'rustc'), RUSTDOC=str(toolchain/'rustdoc'),
    CARGO_HOME=str(root/'cache/cargo'), CARGO_TARGET_DIR=str(root/'target'),
    CARGO_BUILD_JOBS='1', RUST_TEST_THREADS='1', RAYON_NUM_THREADS='1', TMPDIR=str(root/'temp'))
receipt = {'source': revision, 'archive_sha256': expected, 'runner': 'd1323898b255a3ed435eb83fa0f7b0cf',
    'host': {'system': platform.system(), 'machine': platform.machine(), 'release': platform.release()},
    'scope': 'owned managed API model/pipe controls and direct test-target Clippy only',
    'needs': 'cpus=1,mem=4g,disk=12g', 'commands': [], 'executed_test_binaries': [],
    'seed_lock_sha256': manifest['Cargo.lock'], 'native_vm_gpu_cases_executed': 0}
logs = {}
if resuming:
    receipt = json.loads((root/'running.json').read_text())
    if receipt['source'] != revision or receipt['archive_sha256'] != expected:
        raise ValueError('foreign metadata receipt')
    if len(receipt['commands']) != 1 or receipt['executed_test_binaries']:
        raise ValueError('resume requires metadata-only completion')
    previous = receipt['commands'][0]
    if (previous['name'] != 'resolve-lock' or previous['exit'] != 0
            or not previous['reaped'] or previous['timed_out']
            or sha(root/'resolve-lock.log') != previous['log_sha256']):
        raise ValueError('metadata has no verified successful completion')
    logs['resolve-lock'] = (root/'resolve-lock.log').read_text()
    (root/'running-before-resume.json').write_text(json.dumps(receipt, indent=2)+'\n')
def journal():
    (root/'running.json').write_text(json.dumps(receipt, indent=2)+'\n')
def run(name, command):
    row = {'name': name, 'command': command, 'timed_out': False}
    path = root/(name+'.log')
    with path.open('xb') as log:
        child = subprocess.Popen(command, cwd=source, env=environment, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
        row['pid'] = child.pid
        receipt['commands'].append(row)
        journal()
        try:
            child.wait(timeout=600)
        except subprocess.TimeoutExpired:
            row['timed_out'] = True
            row['descendant_cleanup'] = 'uncertain; parent exit alone cannot establish descendant or API-worker cleanup'
            child.terminate()
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=10)
    row.update(exit=child.returncode, reaped=child.returncode is not None, log_sha256=sha(path))
    logs[name] = path.read_text()
    journal()
    return row
resolved = receipt['commands'][0] if resuming else run('resolve-lock', [
    'nice', '-n', '10', str(toolchain/'cargo'), 'metadata', '--format-version=1'])
generated_registry = [row for row in tomllib.loads((source/'Cargo.lock').read_text())['package'] if 'source' in row]
registry_id = lambda row: (row['name'], row['version'], row['source'], row.get('checksum'))
seed_registry_ids = {registry_id(row) for row in registry}
receipt['registry_subset'] = generated_registry
receipt['registry_seed_subset'] = all(
    row['source'].startswith('registry+') and isinstance(row.get('checksum'), str)
    and registry_id(row) in seed_registry_ids for row in generated_registry)
receipt['generated_lock_sha256'] = sha(source/'Cargo.lock')
compiled_manifest = {str(path.relative_to(source)): sha(path) for path in sorted(source.rglob('*')) if path.is_file()}
receipt['static_source_unchanged'] = ({key: value for key, value in manifest.items() if key != 'Cargo.lock'}
    == {key: value for key, value in compiled_manifest.items() if key != 'Cargo.lock'})
(root/'source-compiled.json').write_text(json.dumps(compiled_manifest, indent=2)+'\n')
compiled = None
if resolved['exit'] == 0 and not resolved['timed_out'] and receipt['registry_seed_subset'] and receipt['static_source_unchanged']:
    if resuming:
        with (root/'RESUME-after-metadata.json').open('x') as marker:
            json.dump({'pid': os.getpid(), 'source': revision, 'archive_sha256': expected}, marker)
    compiled = run('compile', ['nice', '-n', '10', str(toolchain/'cargo'), 'test', '-p', 'shards-api',
        '--test', 'completion_managed_api', '--no-run', '--locked', '-j1', '--message-format=json'])
if compiled is not None and compiled['exit'] == 0 and not compiled['timed_out']:
    artifacts = []
    for line in logs['compile'].splitlines():
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            continue
        if (message.get('reason') == 'compiler-artifact' and message.get('target', {}).get('name') == 'completion_managed_api'
                and message.get('profile', {}).get('test') and message.get('executable')):
            artifacts.append(message)
    if len(artifacts) != 1:
        raise ValueError('expected one owned integration-test executable')
    artifact = artifacts[0]
    if Path(artifact['manifest_path']).resolve() != (source/'crates/api/Cargo.toml').resolve():
        raise ValueError('foreign test manifest')
    built = Path(artifact['executable'])
    built.resolve().relative_to((root/'target').resolve())
    pinned = root/'run/completion-managed-api'
    pinned.write_bytes(built.read_bytes())
    pinned.chmod(0o500)
    binary_hash = sha(built)
    if sha(pinned) != binary_hash:
        raise ValueError('copied binary mismatch')
    receipt['executed_test_binaries'].append({'compiled_path': str(built), 'pinned_path': str(pinned), 'sha256': binary_hash})
    tested = run('controls', ['nice', '-n', '10', str(pinned), '--nocapture', '--test-threads=1'])
    receipt['binary_unchanged'] = sha(pinned) == binary_hash and sha(built) == binary_hash
    if not tested['timed_out']:
        run('clippy', ['nice', '-n', '10', str(toolchain/'cargo'), 'clippy', '-p', 'shards-api',
            '--test', 'completion_managed_api', '--locked', '-j1', '--', '-D', 'warnings'])
after = {str(path.relative_to(source)): sha(path) for path in sorted(source.rglob('*')) if path.is_file()}
(root/'source-after.json').write_text(json.dumps(after, indent=2)+'\n')
receipt['source_unchanged'] = compiled_manifest == after
receipt['temp_entries'] = len(list((root/'temp').iterdir()))
names = ['launch_identity_refusal_stops_the_returned_native_owner', 'attach_identity_mismatch_never_stops_the_foreign_owner',
    'observer_uncertainty_remains_typed_and_stops_the_same_owner', 'terminal_output_is_bounded_drained_and_releases_native_receipt_refs']
receipt['selected_names'] = names
receipt['intended_counts'] = ('4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in logs.get('controls', '')
    and all(('test '+name+' ... ') in logs['controls'] for name in names))
receipt['passed'] = (len(receipt['commands']) == 4 and all(row['exit'] == 0 and row['reaped'] and not row['timed_out'] for row in receipt['commands'])
    and receipt['registry_seed_subset'] and receipt['static_source_unchanged']
    and receipt.get('binary_unchanged', False) and receipt['source_unchanged'] and receipt['temp_entries'] == 0 and receipt['intended_counts'])
(root/'result.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'root': str(root), 'result': receipt, 'logs': logs,
    'source_manifest': manifest, 'compiled_source_manifest': compiled_manifest,
    'after_source_manifest': after, 'generated_lock': (source/'Cargo.lock').read_text()}, indent=2), flush=True)
sys.exit(0 if receipt['passed'] else 1)
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("revision")
    parser.add_argument("destination", type=Path)
    parser.add_argument("--resume", type=Path)
    args = parser.parse_args()
    name = "api-" + args.revision[:8] + "-" + uuid.uuid4().hex[:8]
    local = args.destination / name
    local.mkdir(parents=True, exist_ok=False)
    remote = str(args.resume) if args.resume else "/Users/adalundhe/.cache/hex-complete-managed-api/" + name
    if not remote.startswith('/Users/adalundhe/.cache/hex-complete-managed-api/api-'):
        raise ValueError('resume path is outside the owned job namespace')
    expected = hashlib.sha256(args.archive.read_bytes()).hexdigest()
    command = shlex.join([
        "/Users/adalundhe/.cache/hex-lead/python-3.13.18-20261026/python/bin/python3",
        "-c", REMOTE, remote, expected, args.revision, 'resume' if args.resume else 'new',
    ])
    argv = [str(Path.home() / ".local/bin/kiln"), "run", "--on", "d1323898b255a3ed435eb83fa0f7b0cf",
            "--needs", "cpus=1,mem=4g,disk=12g", "--no-sync", "--quiet"]
    if not args.resume:
        argv.append('--stdin')
    argv.extend(['--', command])
    with args.archive.open("rb") as source, (local / "kiln.log").open("xb") as output:
        child = subprocess.Popen(argv, stdin=subprocess.DEVNULL if args.resume else source,
                                 stdout=output, stderr=subprocess.STDOUT)
        receipt = {"pid": child.pid, "remote": remote, "source": args.revision, "archive_sha256": expected, "argv": argv}
        (local / "submission.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps({"pid": child.pid, "local": str(local), "remote": remote}), flush=True)
        code = child.wait()
    (local / "kiln.exit").write_text(str(code) + "\n")
    raw = (local / "kiln.log").read_text()
    for match in re.finditer(r"(?m)^\{", raw):
        try:
            result, _ = json.JSONDecoder().raw_decode(raw[match.start():])
        except json.JSONDecodeError:
            continue
        if isinstance(result, dict) and "result" in result and "logs" in result:
            (local / "complete.json").write_text(json.dumps(result, indent=2) + "\n")
            print(json.dumps(result["result"], indent=2), flush=True)
            for name, log in result["logs"].items():
                if name == "resolve-lock":
                    continue
                print(name + "\n" + log[-10000:], flush=True)
            raise SystemExit(code)
    print(json.dumps({"local_cli_exit": code, "complete_driver_receipt": False, "raw_output": raw}), flush=True)
    raise SystemExit(code if code else 1)


if __name__ == "__main__":
    main()
