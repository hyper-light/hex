import os,pathlib,json,hashlib,subprocess,sys,re,shutil
root=pathlib.Path.home()/'.cache/hex-complete-shards-managed-rootdae-v1';src=root/'src';proof=root/'proof';proof.mkdir(exist_ok=False)
manifest=json.loads((src/'.hex-light-source.json').read_text());assert manifest['source']=='dae0687b4fe1708d0fcd9b24b1b92172bd6b411d'
for name in ['cargo','target','cache','tmp']:(root/name).mkdir(exist_ok=False)
shutil.copytree(pathlib.Path.home()/'.cache/hex-complete-shards-managed-sdk-v2/cargo/registry',root/'cargo/registry')
env=os.environ.copy();env.update(CARGO_HOME=str(root/'cargo'),CARGO_TARGET_DIR=str(root/'target'),XDG_CACHE_HOME=str(root/'cache'),TMPDIR=str(root/'tmp'),CARGO_BUILD_JOBS='1',RUST_TEST_THREADS='1',CARGO_INCREMENTAL='0',CARGO_NET_RETRY='0',CLANG_MODULE_CACHE_PATH=str(root/'cache/clang'))
for key in list(env):
 if key.startswith('DYLD_'):env.pop(key)
receipt={'source':manifest['source'],'commands':[],'native_gpu':False,'vm':False,'active_pids':[],'selected_counts':{}}
def save():
 receipt['tmp_entries']=len(list((root/'tmp').iterdir()));(proof/'receipt.json').write_text(json.dumps(receipt,indent=2))
def run(label,args,expected=None):
 with (proof/(label+'.log')).open('wb') as output:
  child=subprocess.Popen(['nice','-n','10']+args,cwd=src,env=env,stdout=output,stderr=subprocess.STDOUT)
  receipt['active_pids']=[child.pid];save();code=child.wait();receipt['active_pids']=[]
 data=(proof/(label+'.log')).read_bytes();row={'label':label,'argv':args,'pid':child.pid,'exit':code,'reaped':True,'sha256':hashlib.sha256(data).hexdigest()};receipt['commands'].append(row);save();print(json.dumps(row),flush=True)
 if code:print(data.decode(errors='replace')[-16000:],flush=True);sys.exit(code)
 if expected is not None:
  found=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',data.decode())
  assert found and tuple(map(int,found.groups()))==expected,(label,found.groups() if found else None)
  receipt['selected_counts'][label]=list(expected);save()
run('rustc',['rustc','-vV'])
original=(src/'Cargo.lock').read_bytes();assert hashlib.sha256(original).hexdigest()=='1e9ae2e5e95e103c27bce8e0f7294900984825d22c9926f770c63c872d547386'
(proof/'Cargo.lock.seed').write_bytes(original)
run('metadata',['cargo','metadata','--format-version','1'])
generated=(src/'Cargo.lock').read_bytes();(proof/'Cargo.lock.generated').write_bytes(generated)
def registry(data):
 result=set()
 for part in data.decode().split('[[package]]')[1:]:
  def field(name):
   found=re.search(r'^'+name+r' = (.*)$',part,re.M)
   return json.loads(found.group(1)) if found else None
  source=field('source')
  if source and source.startswith('registry+'):
   name,version,checksum=field('name'),field('version'),field('checksum')
   assert name and version and checksum
   result.add((name,version,source,checksum))
 return result
added=registry(generated)-registry(original);assert not added,added
receipt['lock']={'seed_sha256':hashlib.sha256(original).hexdigest(),'generated_sha256':hashlib.sha256(generated).hexdigest(),'registry_tuples':len(registry(generated)),'new_tuples':list(added)};save()
for label,name in [('inline-stop','client::tests::managed_inline_stop_completion_is_already_stopped_to_waiters'),('scope-clone','client::tests::managed_scope_and_checked_clones_retain_native_lifetime')]:
 run(label,['cargo','test','-p','shards-api','--lib','--locked',name,'--','--exact','--test-threads=1'],(1,0,0))
run('api-clippy',['cargo','clippy','-p','shards-api','--lib','--locked','--','-D','warnings'])
wrong=[]
for name,expected in manifest['files'].items():
 if name=='Cargo.lock':expected=receipt['lock']['generated_sha256']
 if hashlib.sha256((src/name).read_bytes()).hexdigest()!=expected:wrong.append(name)
assert not wrong,wrong
receipt['source_post']={'files_verified':len(manifest['files']),'mismatches':wrong}
receipt['binaries']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'target/debug/deps').iterdir() if p.is_file() and p.name.startswith('shards_api-') and not p.suffix and os.access(p,os.X_OK)}
receipt['complete']=True;save();print(json.dumps(receipt),flush=True)
