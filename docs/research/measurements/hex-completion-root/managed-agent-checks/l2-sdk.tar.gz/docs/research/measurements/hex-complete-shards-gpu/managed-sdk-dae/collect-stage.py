import pathlib,json,hashlib,tarfile
root=pathlib.Path.home()/'.cache/hex-complete-shards-managed-rootdae-v1';src=root/'src';proof=root/'proof'
manifest=json.loads((src/'.hex-light-source.json').read_text());receipt=json.loads((proof/'receipt.json').read_text());assert receipt['complete'] and not receipt['active_pids']
wrong=[]
for name,expected in manifest['files'].items():
 if name=='Cargo.lock':expected=receipt['lock']['generated_sha256']
 if hashlib.sha256((src/name).read_bytes()).hexdigest()!=expected:wrong.append(name)
assert not wrong,wrong
post={'files_verified':len(manifest['files']),'mismatches':wrong,'tmp_entries':len(list((root/'tmp').iterdir())),'active_pids':receipt['active_pids']}
(proof/'source-independent-post.json').write_text(json.dumps(post,indent=2));(proof/'source-input.json').write_text(json.dumps(manifest,indent=2))
archive=root/'proof-small.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for path in sorted(proof.iterdir()):
  if path.is_file() and path.name!='Cargo.lock.seed':tar.add(path,arcname=path.name)
 data=(root/'transfer.json').read_bytes()
 import io
 info=tarfile.TarInfo('transfer.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
data=archive.read_bytes();result={'archive_bytes':len(data),'archive_sha256':hashlib.sha256(data).hexdigest(),'members':{},'post':post}
with tarfile.open(archive,'r:gz') as tar:
 for member in tar.getmembers():result['members'][member.name]={'bytes':member.size,'sha256':hashlib.sha256(tar.extractfile(member).read()).hexdigest()}
(root/'proof-small.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
