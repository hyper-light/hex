import hashlib,io,json,pathlib,sys,tarfile
root=pathlib.Path.home()/'.cache/hex-complete-shards-managed-rootdae-v1'
assert not root.exists(), 'private scope exists'
data=sys.stdin.buffer.read(177606+1)
assert len(data)==177606 and hashlib.sha256(data).hexdigest()=='a0fc03a789a5a0b6df07dc15bc197213b14a4bac29e0105de8c695243a128b65'
root.mkdir(parents=True);(root/'src').mkdir();(root/'source-input.tar.gz').write_bytes(data)
seen=set()
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tar:
 for item in tar.getmembers():
  path=pathlib.PurePosixPath(item.name)
  assert item.isfile() and not path.is_absolute() and '..' not in path.parts and item.name not in seen
  seen.add(item.name);target=root/'src'/item.name;target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as output: output.write(tar.extractfile(item).read(item.size+1))
  target.chmod(item.mode & 511)
manifest=json.loads((root/'src/.hex-light-source.json').read_text())
wrong=[]
for path,expected in manifest['files'].items():
 expected=manifest.get('private_workspace_overlay',{}).get(path,expected)
 if hashlib.sha256((root/'src'/path).read_bytes()).hexdigest()!=expected:wrong.append(path)
assert not wrong,wrong
receipt={'source':manifest['source'],'files_verified':len(manifest['files']),'mismatches':wrong,'archive_sha256':'a0fc03a789a5a0b6df07dc15bc197213b14a4bac29e0105de8c695243a128b65','archive_bytes':177606}
(root/'transfer.json').write_text(json.dumps(receipt));print(json.dumps(receipt),flush=True)
