//! Actual Windows delete body and Counts with an explicit fake kernel; no native calls.
use std::sync::{Mutex,atomic::{AtomicBool,AtomicUsize,Ordering}};
use hex_api::{BoxId,Refusal,Signal};
use hex_core::job::{self,Sent};
#[derive(Debug, Default)]
struct Counts {
    /// Forks the box saw refused at its active-process limit — the node's own `exec` into a full box,
    /// observed synchronously ([`JobBox::exec`]). A member's internal fork, refused in that member, has
    /// no §3-clean job-side signal and is not counted here (`Usage::pids_refused`).
    pids_refused: u64,
    /// Signals Hex ended the box's job for, so [`super::proc`] reads a terminated member's exit code as
    /// the signal.
    sent: Sent,
    deletion: Deletion,
}

#[derive(Debug, Default, PartialEq, Eq)]
enum Deletion {
    #[default]
    Live,
    Requested,
    Released,
}


struct Kernel {
    calls:AtomicUsize,
    fail_first:bool,
    asynchronous:bool,
    live:AtomicBool,
}
impl Kernel {
    fn terminate(&self,_:u32)->std::io::Result<()> {
        let call=self.calls.fetch_add(1,Ordering::SeqCst);
        if self.fail_first && call==0 {return Err(std::io::Error::from_raw_os_error(5));}
        if !self.asynchronous {self.live.store(false,Ordering::SeqCst);}
        Ok(())
    }
}
struct State {
    id:BoxId,
    job:Kernel,
    stopping:AtomicBool,
    counts:Mutex<Counts>,
}
impl State {
    fn counts(&self)->Result<std::sync::MutexGuard<'_,Counts>,Refusal> {
        self.counts.lock().map_err(|_|Refusal::Broken("test counts lock poisoned".into()))
    }
}
struct JobBox {state:State}
impl JobBox {
    fn native_job(&self)->Result<&Kernel,Refusal> {Ok(&self.state.job)}
    fn scope_population(&self)->std::io::Result<u64> {Ok(u64::from(self.state.job.live.load(Ordering::SeqCst)))}
    fn live_processes(&self)->Result<u64,Refusal> {self.scope_population().map_err(|e|Refusal::os("fake scope",e))}
    fn uncertain(&self)->Refusal {Refusal::Lifecycle{id:self.id().clone(),cause:hex_api::LifecycleCause::Uncertain}}
    fn id(&self)->&BoxId {&self.state.id}
    pub fn delete(&self) -> Result<(), Refusal> {
        self.state.stopping.store(true, Ordering::SeqCst);
        let request = {
            let mut c = self.state.counts()?;
            match c.deletion {
                Deletion::Released => return Ok(()),
                Deletion::Requested => false,
                Deletion::Live => {
                    c.sent.add(Signal::KILL);
                    true
                }
            }
        };
        if request {
            self.native_job()?
                .terminate(job::terminated_code(Signal::KILL))
                .map_err(|e| Refusal::os("ending a box's job", e))?;
            let mut c = self.state.counts()?;
            if c.deletion == Deletion::Live {
                c.deletion = Deletion::Requested;
            }
        }
        if self.live_processes()? != 0 {
            return Err(self.uncertain());
        }
        self.state.counts()?.deletion = Deletion::Released;
        Ok(())
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    fn fixture(fail_first:bool,asynchronous:bool)->JobBox {
        JobBox{state:State{
            id:BoxId::new("owned-job").unwrap(),
            job:Kernel{calls:AtomicUsize::new(0),fail_first,asynchronous,live:AtomicBool::new(true)},
            stopping:AtomicBool::new(false),counts:Mutex::new(Counts::default()),
        }}
    }
    /// AC-T7.4.1: an OS refusal cannot become positive terminal proof on the next delete.
    #[test]
    fn failed_termination_is_not_cached_as_a_completed_delete() {
        let boxed=fixture(true,false);
        assert!(boxed.delete().is_err());
        assert!(boxed.state.job.live.load(Ordering::SeqCst));
        boxed.delete().unwrap();
        assert!(!boxed.state.job.live.load(Ordering::SeqCst),"a later delete claimed success while the same native job remained live");
        assert_eq!(boxed.state.job.calls.load(Ordering::SeqCst),2);
        boxed.delete().unwrap();
        assert_eq!(boxed.state.job.calls.load(Ordering::SeqCst),2,"an already proved empty job was dispatched again");
    }
    /// AC-T7.4.1: the controller ending/request acceptance is not the helper scope being empty.
    #[test]
    fn accepted_termination_retains_ownership_until_the_whole_scope_is_empty() {
        let boxed=fixture(false,true);
        assert!(boxed.delete().is_err(),"accepted termination freed an envelope with a live helper");
        assert!(boxed.state.job.live.load(Ordering::SeqCst));
        // A later external completion/query observes the exact same scope after its helper ends.
        boxed.state.job.live.store(false,Ordering::SeqCst);
        boxed.delete().unwrap();
        let calls=boxed.state.job.calls.load(Ordering::SeqCst);
        boxed.delete().unwrap();
        assert_eq!(boxed.state.job.calls.load(Ordering::SeqCst),calls);
    }
}
