use super::*;

#[derive(Default)]
struct RelayRuntime {
    sim: hex_api::sim::SimRuntime,
    creates: AtomicUsize,
    deletes: AtomicUsize,
}

impl Runtime for RelayRuntime {
    fn classes(&self) -> Vec<hex_api::Class> {
        self.sim.classes()
    }
    fn create(&self, spec: BoxSpec) -> Result<BoxInfo, Refusal> {
        self.creates.fetch_add(1, Ordering::SeqCst);
        self.sim.create(spec)
    }
    fn start(&self, id: &BoxId) -> Result<(), Refusal> {
        self.sim.start(id)
    }
    fn exec(&self, id: &BoxId, p: Program, s: Stdio) -> Result<Box<dyn Proc>, Refusal> {
        self.sim.exec(id, p, s)
    }
    fn run(&self, spec: BoxSpec, p: Program, s: Stdio) -> Result<Box<dyn Proc>, Refusal> {
        self.sim.run(spec, p, s)
    }
    fn signal(&self, id: &BoxId, signal: Signal) -> Result<(), Refusal> {
        self.sim.signal(id, signal)
    }
    fn inspect(&self, id: &BoxId) -> Result<BoxInfo, Refusal> {
        self.sim.inspect(id)
    }
    fn usage(&self, id: &BoxId) -> Result<Usage, Refusal> {
        self.sim.usage(id)
    }
    fn list(&self) -> Result<Vec<BoxInfo>, Refusal> {
        self.sim.list()
    }
    fn delete(&self, id: &BoxId) -> Result<(), Refusal> {
        self.deletes.fetch_add(1, Ordering::SeqCst);
        self.sim.delete(id)
    }
}

fn relay_start(key: Key) -> Envelope {
    Envelope {
        msg: peer::Msg::Start {
            key,
            demand: Demand {
                need: Resources {
                    cpu_milli: u64::from(hex_api::MIN_CPU_MILLI),
                    mem_bytes: hex_api::MIN_MEMORY,
                    ..Resources::default()
                },
                kind: Kind::Plain,
                class: hex_sim::model::Class::Oci,
                ask: Ask::default(),
            },
        },
        payload: Some(Payload {
            spec: BoxSpec {
                id: BoxId::new("relay-caller").unwrap(),
                bounds: Bounds {
                    cpu_max_milli: Some(hex_api::MIN_CPU_MILLI),
                    memory_max: Some(hex_api::MIN_MEMORY),
                    ..Bounds::default()
                },
                class: ClassSpec::Process,
                owner: None,
            },
            start: false,
        }),
        refusal: None,
    }
}

fn relay_receiver(dir: &Path, runtime: Arc<RelayRuntime>) -> (Arc<Service>, Receiver<Queued>) {
    let mut owner = NodeSpec::new(NodeId(0), Resources::default());
    owner.classes = Classes::NONE;
    let peer::Msg::Start { demand, .. } = relay_start(Key {
        owner: 0,
        epoch: 1,
        seq: 1,
    })
    .msg
    else {
        unreachable!()
    };
    let cluster = Cluster::single_owner(
        vec![owner, NodeSpec::new(NodeId(1), demand.need)],
        Vec::new(),
    );
    let (send, receive) = channel();
    let service = advertise_timing_service(
        NodeId(1),
        dir,
        cluster,
        Runtimes::new([(hex_sim::model::Class::Oci, runtime as Arc<dyn Runtime>)]).unwrap(),
        send,
    );
    (service, receive)
}

fn relay_hear(
    service: &Service,
    message: &Envelope,
    epoch: u64,
    seq: u64,
) -> Result<dto::Reply, Refusal> {
    service.command(dto::Command::Hear {
        from: 0,
        packet: packet(message, &[], epoch, seq, Vec::new(), &service.realm).unwrap(),
    })
}

fn relay_control(msg: peer::Msg) -> Envelope {
    Envelope {
        msg,
        payload: None,
        refusal: None,
    }
}

/// AC-T7.4.1/LB03: a configured sender's wrong-owner Start must refuse without consuming the
/// next transport stamp. Exercise Service/Order/Driver and counted simulated runtime effects.
#[test]
fn wrong_owner_start_does_not_consume_the_legitimate_peers_next_stamp() {
    let dir = tempfile::tempdir().unwrap();
    let runtime = Arc::new(RelayRuntime::default());
    let (service, feedback) = relay_receiver(dir.path(), Arc::clone(&runtime));
    let key = Key {
        owner: 0,
        epoch: 1,
        seq: 1,
    };
    let start = relay_start(key);
    relay_hear(&service, &relay_control(peer::Msg::Holds { key }), 1, 1).unwrap();
    let row = dir.path().join("transport/peer-0.rec");
    let before = std::fs::read(&row).unwrap();
    let rejected = relay_hear(&service, &relay_start(Key { owner: 1, ..key }), 2, 1);
    let after = std::fs::read(&row).unwrap();
    let effects_after_refusal = (
        runtime.creates.load(Ordering::SeqCst),
        runtime.deletes.load(Ordering::SeqCst),
        runtime.list().unwrap().len(),
    );
    let corrected = relay_hear(&service, &start, 2, 1);
    // Even on RED, demonstrate later legitimate progress and clean up before asserting.
    relay_hear(&service, &start, 2, 2).unwrap();
    let created = service.driver.status(key).unwrap().unwrap().created;
    let peer::Msg::Start { demand, .. } = start.msg else {
        unreachable!()
    };
    relay_hear(
        &service,
        &relay_control(peer::Msg::Delete { key, demand }),
        2,
        3,
    )
    .unwrap();
    relay_hear(&service, &relay_control(peer::Msg::Forget { key }), 2, 4).unwrap();
    drop(feedback);
    eprintln!(
        "wrong-owner refused={rejected:?}; order_unchanged={}; corrected={corrected:?}; later_created={created}; effects_after_refusal={effects_after_refusal:?}; cleanup_boxes={}; cleanup_row={}; permits={}",
        before == after,
        runtime.list().unwrap().len(),
        service.driver.status(key).unwrap().is_some(),
        service.queued.load(Ordering::Acquire)
    );
    assert!(matches!(
        rejected,
        Err(Refusal::Invalid {
            what: "placement",
            ..
        })
    ));
    assert_eq!(effects_after_refusal, (0, 0, 0));
    assert!(created);
    assert_eq!(runtime.creates.load(Ordering::SeqCst), 1);
    assert_eq!(runtime.deletes.load(Ordering::SeqCst), 1);
    assert!(runtime.list().unwrap().is_empty());
    assert!(service.driver.status(key).unwrap().is_none());
    assert_eq!(service.queued.load(Ordering::Acquire), 0);
    assert_eq!(
        after, before,
        "refused wrong-owner Start advanced durable transport order"
    );
    assert!(
        corrected.is_ok(),
        "legitimate correction at the refused stamp must progress"
    );
}

/// AC-T7.4.1/LB03: retained receive order fences an old Start after physical Delete, Forget,
/// receiver restart and a newer sender epoch. Refused identity/retry changes must not consume it.
#[test]
fn delayed_start_stays_fenced_through_forget_restart_and_new_sender_epoch() {
    let dir = tempfile::tempdir().unwrap();
    let runtime = Arc::new(RelayRuntime::default());
    let (service, feedback) = relay_receiver(dir.path(), Arc::clone(&runtime));
    let key = Key {
        owner: 0,
        epoch: 1,
        seq: 1,
    };
    let start = relay_start(key);
    relay_hear(&service, &start, 1, 1).unwrap();
    let row = dir.path().join("transport/peer-0.rec");
    let first = std::fs::read(&row).unwrap();
    relay_hear(&service, &start, 1, 1).unwrap();
    let repeated = std::fs::read(&row).unwrap();
    let mut changed = start.clone();
    changed.payload.as_mut().unwrap().spec.id = BoxId::new("changed-at-same-stamp").unwrap();
    let changed_reply = relay_hear(&service, &changed, 1, 1);
    let after_changed = std::fs::read(&row).unwrap();
    let peer::Msg::Start { demand, .. } = start.msg else {
        unreachable!()
    };
    relay_hear(
        &service,
        &relay_control(peer::Msg::Delete { key, demand }),
        1,
        2,
    )
    .unwrap();
    relay_hear(&service, &start, 1, 1).unwrap();
    let ended_after_delayed = service.driver.status(key).unwrap().unwrap().ended;
    relay_hear(&service, &relay_control(peer::Msg::Forget { key }), 1, 3).unwrap();
    let forgotten = service.driver.status(key).unwrap().is_none();
    let retained = std::fs::read(&row).unwrap();
    let receiver_epoch = service.order.lock().unwrap().epoch;
    drop(feedback);
    drop(service);

    let (service, feedback) = relay_receiver(dir.path(), Arc::clone(&runtime));
    let restarted = service.order.lock().unwrap().epoch > receiver_epoch;
    relay_hear(&service, &start, 1, 1).unwrap();
    let after_restart = std::fs::read(&row).unwrap();
    let old_key_absent = service.driver.status(key).unwrap().is_none();
    let next_key = Key { seq: 2, ..key };
    let next_start = relay_start(next_key);
    let mut foreign_realm = packet(&next_start, &[], 2, 1, Vec::new(), &service.realm).unwrap();
    foreign_realm.cluster = "foreign-realm".into();
    let realm_reply = service.command(dto::Command::Hear {
        from: 0,
        packet: foreign_realm,
    });
    let sender_reply = service.command(dto::Command::Hear {
        from: 2,
        packet: packet(&next_start, &[], 2, 1, Vec::new(), &service.realm).unwrap(),
    });
    let after_refusals = std::fs::read(&row).unwrap();
    let unknown_sender_absent = !dir.path().join("transport/peer-2.rec").exists();
    relay_hear(&service, &relay_control(peer::Msg::Holds { key }), 2, 1).unwrap();
    let new_epoch = std::fs::read(&row).unwrap();
    relay_hear(&service, &next_start, 1, u64::MAX).unwrap();
    let after_old_epoch = std::fs::read(&row).unwrap();
    let fenced_effects = (
        runtime.creates.load(Ordering::SeqCst),
        runtime.deletes.load(Ordering::SeqCst),
        runtime.list().unwrap().len(),
    );
    relay_hear(&service, &next_start, 2, 2).unwrap();
    let later_created = service.driver.status(next_key).unwrap().unwrap().created;
    relay_hear(
        &service,
        &relay_control(peer::Msg::Delete {
            key: next_key,
            demand,
        }),
        2,
        3,
    )
    .unwrap();
    relay_hear(
        &service,
        &relay_control(peer::Msg::Forget { key: next_key }),
        2,
        4,
    )
    .unwrap();
    // No external resources exist: only this simulator's boxes and owned temporary record files.
    let leftovers = runtime.list().unwrap();
    for info in &leftovers {
        runtime.delete(&info.id).unwrap();
    }
    drop(feedback);
    eprintln!(
        "delayed-start changed={changed_reply:?}; realm={realm_reply:?}; sender={sender_reply:?}; restarted={restarted}; old_key_absent={old_key_absent}; fenced_effects={fenced_effects:?}; later_created={later_created}; cleanup_leftovers={}; permits={}",
        leftovers.len(),
        service.queued.load(Ordering::Acquire)
    );
    assert!(matches!(changed_reply, Err(Refusal::Broken(_))));
    assert_eq!(first, repeated);
    assert_eq!(first, after_changed);
    assert!(ended_after_delayed && forgotten && restarted && old_key_absent);
    assert_eq!(retained, after_restart);
    assert!(matches!(
        realm_reply,
        Err(Refusal::Invalid {
            what: "scheduler cluster",
            ..
        })
    ));
    assert!(matches!(
        sender_reply,
        Err(Refusal::Invalid {
            what: "scheduler sender",
            ..
        })
    ));
    assert!(unknown_sender_absent);
    assert_eq!(retained, after_refusals);
    assert_eq!(new_epoch, after_old_epoch);
    assert_eq!(fenced_effects, (1, 1, 0));
    assert!(later_created);
    assert!(leftovers.is_empty());
    assert_eq!(runtime.creates.load(Ordering::SeqCst), 2);
    assert_eq!(runtime.deletes.load(Ordering::SeqCst), 2);
    assert!(service.driver.status(next_key).unwrap().is_none());
    assert_eq!(service.queued.load(Ordering::Acquire), 0);
}
