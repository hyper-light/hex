from pathlib import Path
import hashlib,json,re,sys
scope=Path(sys.argv[1]).resolve()
source=scope/'source'
reference=scope/'reference'
receipt=json.loads((scope/'reference.json').read_text())
for name,digest in receipt['sha256'].items():
 if hashlib.sha256((reference/name).read_bytes()).hexdigest()!=digest:
  raise SystemExit('signed reference differs: '+name)

def block(text,marker):
 start=text.index(marker)
 opened=text.index('{',start)
 depth=1; end=opened+1
 while depth and end<len(text):
  if text[end]=='{':depth+=1
  elif text[end]=='}':depth-=1
  end+=1
 if depth:raise SystemExit('unbalanced source block: '+marker)
 return start,end,text[start:end]

ported={}
def replace(name,markers):
 target=source/name
 old=target.read_text(); expected=(reference/name).read_text()
 for marker in markers:
  a,b,_=block(old,marker)
  _,_,new=block(expected,marker)
  old=old[:a]+new+old[b:]
  ported[name+':'+marker]=hashlib.sha256(new.encode()).hexdigest()
 target.write_text(old)
replace('crates/hex-sim/src/model.rs',['pub struct GpuLoad {','impl Device {','pub fn bind(','pub fn matches('])
replace('crates/hex-sim/src/index.rs',['fn gpu_busy(','fn gpu_idle('])
replace('crates/hex-node/src/facts.rs',['pub fn gpu_facts(','fn hex_gpus_inventory_and_loads_become_the_nodes_gpus('])
# Only tests require numeric-literal syntax compatibility. No production code is regenerated.
for name in ['crates/hex-sim/src/index.rs','crates/hex-sim/src/peer.rs','crates/hex-sim/src/facts.rs']:
 p=source/name;s=p.read_text();at=s.find('\n#[cfg(test)]\nmod tests')
 if at<0:raise SystemExit('missing test boundary '+name)
 head,tail=s[:at],s[at:]
 def field(m):
  space,key,value,comma=m.groups()
  return m.group(0) if value.startswith(('Some(','None')) else space+key+': Some('+value+')'+comma
 tail=re.sub(r'(?m)^(\s+)(busy_per_mille|memory_used): ([^,\n]+?)(,?)$',field,tail)
 tail=re.sub(r'(?m)(\.load\.(?:busy_per_mille|memory_used) = )([^;\n]+);',lambda m:m.group(0) if m[2].startswith(('Some(','None')) else m[1]+'Some('+m[2]+');',tail)
 p.write_text(head+tail)
name='crates/hex-sim/src/index.rs'
p=source/name;s=p.read_text();ref=(reference/name).read_text()
_,_,control=block(ref,'fn unread_gpu_load_preserves_held_identity_and_independent_cpu_progress(')
_,at,_=block(s,'fn asking(')
s=s[:at]+'\n\n    #[test]\n    '+control+s[at:]
p.write_text(s)
ported[name+':retained-control']=hashlib.sha256(control.encode()).hexdigest()
name='crates/hex-node/src/scheduler/device_offer_tests.rs'
(source/name).write_bytes((reference/name).read_bytes())
ported[name]=hashlib.sha256((source/name).read_bytes()).hexdigest()
output={'base':'696b94eff8575c0f046b2725cf9411b66859bcbc + exact02/c59/usize/bf fixture red cohort','signed_quality_source':receipt['signed_source'],'ported_exact_blocks':ported,'final_files':{name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in ['crates/hex-sim/src/model.rs','crates/hex-sim/src/index.rs','crates/hex-sim/src/peer.rs','crates/hex-sim/src/facts.rs','crates/hex-node/src/facts.rs','crates/hex-node/src/scheduler/device_offer_tests.rs']}}
(scope/'port.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
