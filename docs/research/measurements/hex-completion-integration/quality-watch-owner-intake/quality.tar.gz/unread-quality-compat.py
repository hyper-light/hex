from pathlib import Path
import hashlib,json,re,sys
scope=Path(sys.argv[1]).resolve();name='crates/hex-node/src/facts.rs'
ref=(scope/'reference'/name).read_text();target=scope/'source'/name;text=target.read_text()
def block(s,marker):
 start=s.index(marker);opened=s.index('{',start);depth=1;end=opened+1
 while depth:
  if s[end]=='{':depth+=1
  elif s[end]=='}':depth-=1
  end+=1
 return start,end,s[start:end]
marker='fn metal_facts_keep_the_full_native_registry_identity_and_budget('
a,b,_=block(text,marker);_,_,fixed=block(ref,marker)
target.write_text(text[:a]+fixed+text[b:])
name2='crates/hex-sim/src/peer/adversarial_device_recovery_tests.rs'
p=scope/'source'/name2;s=p.read_text()
def field(m):
 space,key,value,comma=m.groups()
 return m.group(0) if value.startswith(('Some(','None')) else space+key+': Some('+value+')'+comma
s=re.sub(r'(?m)^(\s+)(busy_per_mille|memory_used): ([^,\n]+?)(,?)$',field,s)
s=re.sub(r'(?m)(\.load\.(?:busy_per_mille|memory_used) = )([^;\n]+);',lambda m:m.group(0) if m[2].startswith(('Some(','None')) else m[1]+'Some('+m[2]+');',s)
s=s.replace('assert_eq!(spec.devices[1].load.memory_used, 0);','assert_eq!(spec.devices[1].load.memory_used, Some(0));')
p.write_text(s)
receipt={'production_delta_from_v1':'NONE','same_signed_quality_source':'2ce0bcd477dd29a0057dd56f534fa11c15a81330','compat_exact_identity_function_sha256':hashlib.sha256(fixed.encode()).hexdigest(),'files_sha256':{n:hashlib.sha256((scope/'source'/n).read_bytes()).hexdigest() for n in [name,name2]}}
(scope/'compat.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
