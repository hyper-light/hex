#!/usr/bin/env python3
"""Submit focused pure tests to private admitted d132; never execute a native backend."""
import gzip
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys
import io
import tarfile

requested_revision,tag=sys.argv[1:3]
requested_cohort=sys.argv[3] if len(sys.argv)>3 else 'c3bd27e84680ee4d587c5be374b361a567f2419f'
revision=subprocess.check_output(['git','rev-parse',requested_revision+'^{commit}'],text=True).strip()
free=int(subprocess.check_output(['df','-k','.'],text=True).splitlines()[-1].split()[3])
if free<30*1024*1024: raise SystemExit('hold source transfer: local free below30GiB')
base=Path('docs/research/measurements/hex-complete-lifecycle')
local=Path('/Users/adalundhe/.cache/hex-lead/transfers')/('complete-lifecycle-01a1c767-'+tag)
local.mkdir(parents=True,exist_ok=False)
cohort=subprocess.check_output(['git','rev-parse',requested_cohort+'^{commit}'],text=True).strip()
base_revision='b06b1760bb690c9e29a31f99efdb998cf8279c36'
# Exact ROOT shared source, with only the named original production subject and tests overlaid.
overlays={}
for p in ['crates/hex-core/src/record.rs','crates/hex-core/src/watch.rs']:
    overlays[p]=subprocess.check_output(['git','show',revision+':'+p])
original=subprocess.check_output(['git','archive','--format=tar',cohort])
stream=io.BytesIO()
manifest={'source_revision':revision,'shared_cohort':cohort,'overlays':{p:hashlib.sha256(data).hexdigest() for p,data in overlays.items()},'native_effects':0}
with tarfile.open(fileobj=io.BytesIO(original),mode='r:') as source, tarfile.open(fileobj=stream,mode='w:') as dest:
    found=set()
    for member in source.getmembers():
        found.add(member.name)
        if not member.isfile():dest.addfile(member);continue
        data=overlays.get(member.name)
        if data is None:data=source.extractfile(member).read()
        member.size=len(data);dest.addfile(member,io.BytesIO(data))
    for p,data in overlays.items():
        if p not in found:
            item=tarfile.TarInfo(p);item.size=len(data);dest.addfile(item,io.BytesIO(data))
    data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('docs/research/measurements/hex-complete-lifecycle/cohort.json');info.size=len(data);dest.addfile(info,io.BytesIO(data))
archive=gzip.compress(stream.getvalue(),mtime=0)
(local/'cohort.json').write_text(json.dumps(manifest,indent=2)+'\n')
(local/'source.tar.gz').write_bytes(archive)
sha=hashlib.sha256(archive).hexdigest()
remote='/Users/adalundhe/.cache/hex-complete-lifecycle/01a1c767-'+tag
script=(base/'watch_fallible_check.py').read_text()
command='python3 -c '+shlex.quote(script)+' '+shlex.quote(remote)+' '+sha+' '+revision
meta={'source_revision':revision,'archive_sha256':sha,'archive_bytes':len(archive),'runner':'d1323898b255a3ed435eb83fa0f7b0cf','needs':'cpus=1,mem=4g,disk=12g','remote_root':remote,'local_root':str(local),'free_kib_before':free,'driver_sha256':hashlib.sha256(script.encode()).hexdigest(),'command':command}
(local/'transfer.json').write_text(json.dumps(meta,indent=2)+'\n')
with (local/'cli.log').open('xb') as log:
 child=subprocess.Popen(['/Users/adalundhe/.local/bin/kiln','run','--on','d1323898b255a3ed435eb83fa0f7b0cf','--needs','cpus=1,mem=4g,disk=12g','--no-sync','--stdin','--timeout','1800','--',command],stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT)
 meta['local_cli_pid']=child.pid;(local/'transfer.json').write_text(json.dumps(meta,indent=2)+'\n')
 child.communicate(archive);meta['local_cli_exit']=child.returncode
 meta['cli_log_sha256']=hashlib.sha256((local/'cli.log').read_bytes()).hexdigest()
 (local/'transfer.json').write_text(json.dumps(meta,indent=2)+'\n')
 print(json.dumps({k:v for k,v in meta.items() if k!='command'},indent=2),flush=True)
 print((local/'cli.log').read_text(errors='replace')[-23000:],flush=True)
 raise SystemExit(child.returncode)
