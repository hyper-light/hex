//! AC-T7.4.1: the file-backed peer core drives the actual selected runtime. Publication follows
//! durable admission, physical creation and durable acknowledgement, in that order. A physical
//! box (even an empty process box) holds its reservation until deletion, never merely until exit.

use std::collections::BTreeMap;
use std::path::Path;
use std::sync::{Arc, Mutex, MutexGuard, TryLockError};
use std::time::Instant;

use hex_api::{BoxId, BoxInfo, BoxSpec, BoxState, Refusal, Runtime};
use hex_sim::index::Pick;
use hex_sim::model::{Class, Demand, NodeId, NodeSpec, Resources};
use hex_sim::peer::{self, Boxed, Budget, Key, Msg, Stop, Told};

pub mod budget;
mod devices;
mod rows;
use rows::{Context, Rows};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Payload {
    pub spec: BoxSpec,
    pub start: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Envelope {
    pub msg: Msg,
    pub payload: Option<Payload>,
    pub refusal: Option<Refusal>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Notice {
    Started {
        key: Key,
        node: NodeId,
    },
    Ended {
        key: Key,
    },
    Refused {
        key: Key,
        node: NodeId,
        refusal: Refusal,
    },
    /// The box may exist. Admission is retained; an operator may retry deletion or reboot.
    Unknown {
        key: Key,
        refusal: Refusal,
        cleanup: Option<Refusal>,
    },
    Status {
        key: Key,
        info: BoxInfo,
    },
}

#[derive(Debug, Default)]
pub struct Step {
    pub send: Vec<(NodeId, Envelope)>,
    pub notices: Vec<Notice>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Status {
    pub key: Key,
    pub node: Option<NodeId>,
    pub local: bool,
    pub created: bool,
    pub deleting: bool,
    pub ended: bool,
    pub physical: BoxId,
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum Error {
    #[error("placement stopped: {0:?}")]
    Core(Stop),
    #[error(transparent)]
    Runtime(#[from] Refusal),
}

impl From<Stop> for Error {
    fn from(stop: Stop) -> Self {
        Self::Core(stop)
    }
}

/// The operator supplies backend truth. A registry has at most the scheduler's three classes;
/// runtimes without a device-attachment seam cannot silently accept scheduler device assignments.
#[derive(Clone, Default)]
pub struct Runtimes {
    by_class: BTreeMap<Class, Arc<dyn Runtime>>,
}

impl Runtimes {
    pub fn new(
        entries: impl IntoIterator<Item = (Class, Arc<dyn Runtime>)>,
    ) -> Result<Self, Error> {
        let mut by_class = BTreeMap::new();
        for (class, runtime) in entries {
            if by_class.insert(class, runtime).is_some() {
                return Err(invalid("duplicate runtime class").into());
            }
        }
        Ok(Self { by_class })
    }

    fn get(&self, class: Class) -> Result<Arc<dyn Runtime>, Error> {
        self.by_class
            .get(&class)
            .cloned()
            .ok_or_else(|| invalid("no registered runtime for placement class").into())
    }

    /// Query each configured backend without holding any placement or record lock.
    pub fn capacities(&self) -> Result<Vec<(Class, Option<hex_api::Capacity>)>, Error> {
        self.by_class
            .iter()
            .map(|(&class, runtime)| {
                let form = if runtime.classes().contains(&hex_api::Class::Oci) {
                    hex_api::Class::Oci
                } else {
                    hex_api::Class::Process
                };
                Ok((class, runtime.capacity(form)?))
            })
            .collect()
    }
}

fn checked_namespace(namespace: &str) -> Result<&str, Refusal> {
    // 128-bit UUID-width nonce or a complete SHA-256 digest, in canonical hexadecimal.
    if !matches!(namespace.len(), 32 | 64)
        || !namespace
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err(invalid(
            "placement namespace must be 32 or 64 lowercase hexadecimal digits",
        ));
    }
    Ok(namespace)
}

pub fn physical_id(namespace: &str, key: Key) -> Result<BoxId, Refusal> {
    let namespace = checked_namespace(namespace)?;
    BoxId::new(&format!(
        "hex-place-{namespace}-{}-{}-{}",
        key.owner, key.epoch, key.seq
    ))
}

fn invalid(why: impl Into<String>) -> Refusal {
    Refusal::Invalid {
        what: "placement",
        why: why.into(),
    }
}
fn bad(why: impl Into<String>) -> Stop {
    Stop::Damaged(why.into())
}
fn name(kind: &str, key: Key) -> String {
    format!("{kind}-{}-{}-{}", key.owner, key.epoch, key.seq)
}

struct State {
    node: peer::Node,
    rows: Rows,
    stopped: Option<Stop>,
    admission: Option<Refusal>,
}

enum Effect {
    Create(Key, Demand, Box<Payload>),
    Delete(Key, Demand),
}

type Collected = (Step, Vec<Effect>);

/// One node in an explicitly shared cluster namespace.
pub struct Identity<'a> {
    pub namespace: &'a str,
    pub node: NodeId,
}

pub struct Driver {
    state: Mutex<State>,
    // One operation owns physical effects, with no queued waiters: concurrent mutation is refused.
    // The core/record lock is always released before calling any Runtime method.
    operation: Mutex<()>,
    runtimes: Runtimes,
    peers: Vec<NodeId>,
    namespace: String,
}

impl Driver {
    /// Opens standalone state, generating its durable UUID-width namespace only when genuinely
    /// empty. Peers must use boot_in with one explicitly shared cluster namespace.
    pub fn boot(
        id: NodeId,
        nodes: &[NodeSpec],
        models: &[String],
        budget: Budget,
        pick: Pick,
        dir: &Path,
        runtimes: Runtimes,
    ) -> Result<Self, Error> {
        Self::boot_scoped((id, None), nodes, models, budget, pick, dir, runtimes)
    }

    /// All peers in one cluster supply the same canonical namespace. Independent clusters may
    /// share a physical Runtime without sharing physical BoxIds. Existing state must match.
    pub fn boot_in(
        identity: Identity<'_>,
        nodes: &[NodeSpec],
        models: &[String],
        budget: Budget,
        pick: Pick,
        dir: &Path,
        runtimes: Runtimes,
    ) -> Result<Self, Error> {
        checked_namespace(identity.namespace)?;
        Self::boot_scoped(
            (identity.node, Some(identity.namespace)),
            nodes,
            models,
            budget,
            pick,
            dir,
            runtimes,
        )
    }

    fn boot_scoped(
        identity: (NodeId, Option<&str>),
        nodes: &[NodeSpec],
        models: &[String],
        budget: Budget,
        pick: Pick,
        dir: &Path,
        runtimes: Runtimes,
    ) -> Result<Self, Error> {
        let (id, namespace) = identity;
        let mut rows = Rows::open(dir, budget, namespace)?;
        let namespace = rows.namespace().to_owned();
        let mut actual = BTreeMap::new();
        let mut start = Vec::new();
        let mut retained = Resources::default();
        let mut retained_by_class = BTreeMap::<Class, Resources>::new();
        let live_node = nodes
            .iter()
            .find(|node| node.id == id)
            .ok_or_else(|| bad("recovery node is not configured"))?;
        for (key, payload) in rows.running()? {
            // Core demand is durable beside this payload; decode it through core boot below.
            // Select its runtime using the shared model codec, without a second decision format.
            let (demand, ended) = durable_demand(&rows, key, models)?;
            let runtime = runtimes.get(demand.class)?;
            validate(&demand, &payload)?;
            validate_backend(&payload, &runtime)?;
            let physical = physical_id(&namespace, key)?;
            let boxed = match runtime.inspect(&physical) {
                Ok(info) => {
                    if !ended && device_request(&demand) {
                        let selected =
                            peer::recorded_device_specs(rows.row(key)?, &live_node.devices)?
                                .ok_or_else(|| {
                                    bad("a surviving device-bearing box has no durable bindings")
                                })?;
                        devices::verify(&runtime, &physical, &devices::physical(selected)?)?;
                    }
                    if !ended {
                        retained = retained
                            .checked_add(&demand.need)
                            .ok_or_else(|| bad("recovered physical reservations overflow"))?;
                        let class = retained_by_class.entry(demand.class).or_default();
                        *class = class
                            .checked_add(&demand.need)
                            .ok_or_else(|| bad("recovered runtime reservations overflow"))?;
                    }
                    if !ended && payload.start && info.state == BoxState::Created {
                        start.push((runtime, physical));
                    }
                    Boxed::Running
                }
                Err(Refusal::NoSuchBox(_)) => Boxed::Absent,
                Err(why) => return Err(why.into()),
            };
            actual.insert(key, boxed);
        }
        let live = live_node.capacity;
        let pool_use = |classes: hex_sim::model::Classes| {
            retained_by_class
                .iter()
                .filter(|(class, _)| classes.has(**class))
                .try_fold(Resources::default(), |used, (_, more)| {
                    used.checked_add(more)
                        .ok_or_else(|| bad("recovered runtime pool reservations overflow"))
                })
        };
        let mut raised = !live.holds(&retained);
        for pool in &live_node.runtime_pools {
            raised |= !pool.capacity.holds(&pool_use(pool.classes)?);
        }
        // Live FREE room is an admission offer, not a reason to forget an existing physical box.
        // Only the boot ledger gets a floor equal to checked, actually surviving reservations.
        // Service's original facts stay untouched and new local admission is blocked below.
        let recovery_nodes = if raised {
            let mut recovered = nodes.to_vec();
            let local = recovered
                .iter_mut()
                .find(|node| node.id == id)
                .ok_or_else(|| bad("recovery node missing"))?;
            local.capacity = Resources {
                cpu_milli: live.cpu_milli.max(retained.cpu_milli),
                mem_bytes: live.mem_bytes.max(retained.mem_bytes),
                disk_bytes: live.disk_bytes.max(retained.disk_bytes),
                gpus: live.gpus.max(retained.gpus),
            };
            for pool in &mut local.runtime_pools {
                let held = pool_use(pool.classes)?;
                pool.capacity = Resources {
                    cpu_milli: pool.capacity.cpu_milli.max(held.cpu_milli),
                    mem_bytes: pool.capacity.mem_bytes.max(held.mem_bytes),
                    disk_bytes: pool.capacity.disk_bytes.max(held.disk_bytes),
                    gpus: pool.capacity.gpus.max(held.gpus),
                };
            }
            Some(recovered)
        } else {
            None
        };
        let recovery_budget = rows.recovery_budget();
        let mut node = peer::Node::boot(
            id,
            recovery_nodes.as_deref().unwrap_or(nodes),
            models,
            recovery_budget,
            pick,
            &mut rows,
            |key| actual.get(&key).copied().unwrap_or(Boxed::Absent),
        )?;
        node.set_budget(budget);
        // Only validated, recovered records may resume an init; no acknowledgement has escaped.
        for (runtime, id) in start {
            runtime.start(&id)?;
        }
        Ok(Self {
            state: Mutex::new(State {
                node,
                rows,
                stopped: None,
                admission: raised.then(||Refusal::Invalid {
                    what:"local admission",
                    why:format!("current host or runtime pool room cannot cover recovered physical reservations {retained:?}; a successful live-room refresh is required before new local admission"),
                }),
            }),
            operation: Mutex::new(()),
            runtimes,
            peers: nodes.iter().map(|n| n.id).collect(),
            namespace,
        })
    }

    pub fn namespace(&self) -> &str {
        &self.namespace
    }

    pub fn physical_id(&self, key: Key) -> Result<BoxId, Refusal> {
        physical_id(&self.namespace, key)
    }

    fn lock(&self) -> Result<MutexGuard<'_, State>, Error> {
        let state = self
            .state
            .lock()
            .map_err(|_| Refusal::Broken("placement mutex poisoned".into()))?;
        if let Some(stop) = &state.stopped {
            return Err(Error::Core(stop.clone()));
        }
        Ok(state)
    }

    fn operation(&self) -> Result<MutexGuard<'_, ()>, Error> {
        self.operation.try_lock().map_err(|e| {
            match e {
                TryLockError::WouldBlock => Refusal::Exhausted {
                    what: "placement operation",
                    bound: 1,
                },
                TryLockError::Poisoned(_) => {
                    Refusal::Broken("placement operation mutex poisoned".into())
                }
            }
            .into()
        })
    }

    pub fn submit(&self, demand: Demand, payload: Payload) -> Result<(Key, Step), Error> {
        let _operation = self.operation()?;
        validate(&demand, &payload)?;
        let mut state = self.lock()?;
        state.rows.context = Context::NextOwned(payload);
        let State { node, rows, .. } = &mut *state;
        let result = node.submit(demand, rows);
        state.rows.context = Context::None;
        let (key, out) = finish(&mut state, result, true)?;
        let (step, create) = collect(&mut state, out)?;
        drop(state);
        Ok((key, self.drive(step, create)?))
    }

    pub fn hear(&self, from: NodeId, envelope: Envelope) -> Result<Step, Error> {
        let _operation = self.operation()?;
        let mut state = self.lock()?;
        if let Msg::Start { key, demand } = envelope.msg {
            if key.owner != from.0 || !self.peers.contains(&from) {
                return Err(invalid("start owner is not its known sender").into());
            }
            if state.node.demand(key).is_some_and(|d| d != demand) {
                return Err(invalid("start changed its durable demand").into());
            }
            let payload = envelope
                .payload
                .clone()
                .ok_or_else(|| invalid("start has no payload"))?;
            if state.node.owned_keys().any(|(k, _)| k == key)
                && state.rows.payload("own", key)? != payload
            {
                return Err(invalid("start changed its owner's durable payload").into());
            }
            // Runtime::classes is a backend call too: validate after dropping the core lock.
            let prior = state.node.ran_keys().any(|(k, _, _)| k == key);
            if !prior && let Some(why) = &state.admission {
                return Ok(Step {
                    send: vec![(
                        from,
                        Envelope {
                            msg: Msg::Refused { key },
                            payload: None,
                            refusal: Some(why.clone()),
                        },
                    )],
                    notices: vec![Notice::Refused {
                        key,
                        node: state.node.id(),
                        refusal: why.clone(),
                    }],
                });
            }
            if prior && state.rows.payload("ran", key)? != payload {
                return Err(invalid("repeated start changed its payload").into());
            }
            drop(state);
            let checked = validate(&demand, &payload).and_then(|()| {
                let runtime = self.runtimes.get(demand.class)?;
                validate_backend(&payload, &runtime)
            });
            state = self.lock()?;
            match checked {
                Ok(()) => {}
                Err(Error::Runtime(why)) if !prior => {
                    return Ok(Step {
                        send: vec![(
                            from,
                            Envelope {
                                msg: Msg::Refused { key },
                                payload: None,
                                refusal: Some(why),
                            },
                        )],
                        notices: Vec::new(),
                    });
                }
                Err(why) => return Err(why),
            }
            state.rows.context = Context::Start(key, payload);
        } else if envelope.payload.is_some() {
            return Err(invalid("payload outside start").into());
        }
        let State { node, rows, .. } = &mut *state;
        let result = node.hear(from, envelope.msg, rows);
        state.rows.context = Context::None;
        let out = finish(&mut state, result, false)?;
        let (mut step, create) = collect(&mut state, out)?;
        if let (Msg::Refused { key }, Some(refusal)) = (envelope.msg, envelope.refusal) {
            step.notices.push(Notice::Refused {
                key,
                node: from,
                refusal,
            });
        }
        drop(state);
        self.drive(step, create)
    }

    pub fn link_up(&self, peer: NodeId) -> Result<Step, Error> {
        self.change(|node, rows| node.link_up(peer, rows))
    }

    /// Recovery uses the same link-up protocol, including the laptop's self-link. Messages stay
    /// external so a local workload never recurses through the runtime driver.
    pub fn take_recovered(&self) -> Result<Step, Error> {
        self.change(|node, rows| {
            let mut out = Vec::new();
            for peer in &self.peers {
                out.extend(node.link_up(*peer, rows)?);
            }
            Ok(out)
        })
    }

    pub fn refresh_node(&self, spec: NodeSpec) -> Result<(), Error> {
        let _operation = self.operation()?;
        let mut state = self.lock()?;
        let local = spec.id == state.node.id();
        let result = state.node.refresh_node(spec);
        if local {
            state.admission = result.as_ref().err().map(admission_refusal);
        }
        result.map_err(Error::Core)
    }

    /// Admission changes never erase retained rows. A larger persisted read ceiling
    /// precedes any new core row; a smaller current ceiling only refuses new work.
    pub fn set_budget(&self, budget: Budget) -> Result<usize, Error> {
        let _operation = self.operation()?;
        let mut state = self.lock()?;
        let bound = state.rows.control_bound(budget)?;
        state.rows.grow_budget(budget)?;
        state.node.set_budget(budget);
        Ok(bound)
    }

    pub fn control_bound(&self) -> Result<usize, Error> {
        let state = self.lock()?;
        state
            .rows
            .control_bound(state.node.budget())
            .map_err(Error::Core)
    }

    /// A probe that cannot establish current room blocks new reservations, while already held
    /// keys and deletion/control remain available. The refusal remains typed across peer replies.
    pub fn block_admission(&self, why: Refusal) -> Result<(), Error> {
        let _operation = self.operation()?;
        self.lock()?.admission = Some(why);
        Ok(())
    }

    pub fn set_pick(&self, pick: Pick) -> Result<(), Error> {
        let _operation = self.operation()?;
        self.lock()?.node.set_pick(pick);
        Ok(())
    }

    pub fn set_gpu_load(
        &self,
        node: NodeId,
        device: usize,
        load: hex_sim::model::GpuLoad,
    ) -> Result<(), Error> {
        let _operation = self.operation()?;
        let mut state = self.lock()?;
        let result = state.node.set_gpu_load(node, device, load);
        if node == state.node.id()
            && let Err(why) = &result
        {
            state.admission = Some(admission_refusal(why));
        }
        result.map_err(Error::Core)
    }

    /// Bounded node/class aggregates, never individual launch samples. The authenticated transport
    /// publishes only the sender's cells and keeps the snapshot unchanged across packet retries.
    pub fn start_observations(&self) -> Result<Vec<hex_sim::start_cost::StartObservation>, Error> {
        Ok(self.lock()?.node.start_observations())
    }

    pub fn merge_peer_start_observations(
        &self,
        peer: NodeId,
        observations: &[hex_sim::start_cost::StartObservation],
    ) -> Result<(), Error> {
        let _operation = self.operation()?;
        let mut state = self.lock()?;
        let State { node, rows, .. } = &mut *state;
        let result = node.merge_peer_start_observations(peer, observations, rows);
        finish(&mut state, result, false)
    }

    pub fn retry(&self) -> Result<Step, Error> {
        self.change(|node, rows| {
            let mut out = Vec::new();
            node.retry(rows, &mut out)?;
            Ok(out)
        })
    }

    fn change(
        &self,
        change: impl FnOnce(&mut peer::Node, &mut Rows) -> Result<Vec<(NodeId, Msg)>, Stop>,
    ) -> Result<Step, Error> {
        let _operation = self.operation()?;
        let mut state = self.lock()?;
        let State { node, rows, .. } = &mut *state;
        let result = change(node, rows);
        let out = finish(&mut state, result, false)?;
        let (step, create) = collect(&mut state, out)?;
        drop(state);
        self.drive(step, create)
    }

    fn drive(&self, mut step: Step, effects: Vec<Effect>) -> Result<Step, Error> {
        for effect in effects {
            let (key, demand, payload) = match effect {
                Effect::Create(key, demand, payload) => (key, demand, payload),
                Effect::Delete(key, demand) => {
                    // The core verified full-key ownership and persisted Deleting at the owner.
                    // A missing ran row (e.g. dropped Start) is not itself an absence proof.
                    match self
                        .runtimes
                        .get(demand.class)?
                        .delete(&self.physical_id(key)?)
                    {
                        Ok(()) | Err(Refusal::NoSuchBox(_)) => {
                            let next = self.ended(key)?;
                            step.send.extend(next.send);
                            step.notices.extend(next.notices);
                        }
                        Err(why) => step.notices.push(Notice::Unknown {
                            key,
                            refusal: why,
                            cleanup: None,
                        }),
                    }
                    continue;
                }
            };
            let runtime = self.runtimes.get(demand.class)?;
            let id = self.physical_id(key)?;
            let mut spec = payload.spec.clone();
            spec.id = id.clone();
            let selected = self
                .lock()?
                .node
                .assigned_device_specs(key)?
                .ok_or_else(|| bad("physical create has no active receiver reservation"))?;
            spec.devices = devices::physical(selected)?;
            let mut assigned = Vec::new();
            assigned
                .try_reserve_exact(spec.devices.len())
                .map_err(|_| Refusal::Exhausted {
                    what: "physical device assignments",
                    bound: spec.devices.len(),
                })?;
            assigned.extend_from_slice(&spec.devices);
            let mut launched = None;
            let made = match runtime.inspect(&id) {
                Ok(info) => Ok(info),
                Err(Refusal::NoSuchBox(_)) => {
                    // Combined launch service includes any staging performed inside create.
                    // Explicit modeled transfer/work costs omit this aggregate in the scorer.
                    // Recovery/preexisting boxes do not create a second or partial sample.
                    launched = Some(Instant::now());
                    runtime.create(spec)
                }
                Err(why) => {
                    step.notices.push(Notice::Unknown {
                        key,
                        refusal: why,
                        cleanup: None,
                    });
                    continue;
                }
            };
            let made = made.and_then(|info| {
                devices::verify(&runtime, &id, &assigned).map_err(|error| match error {
                    Error::Runtime(why) => why,
                    Error::Core(_) => Refusal::Broken(
                        "native device bindings disagree with their durable reservation".into(),
                    ),
                })?;
                if payload.start && info.state == BoxState::Created {
                    runtime.start(&id)?;
                }
                Ok(())
            });
            match made {
                Ok(()) => {
                    let elapsed = launched
                        .map(|at| u64::try_from(at.elapsed().as_nanos()))
                        .transpose();
                    match elapsed {
                        Ok(elapsed) => self.completed(key, None, elapsed, &mut step)?,
                        Err(why) => step.notices.push(Notice::Unknown {
                            key,
                            refusal: invalid(format!("combined launch duration: {why}")),
                            cleanup: None,
                        }),
                    }
                }
                Err(why @ Refusal::Exists(_)) => step.notices.push(Notice::Unknown {
                    key,
                    refusal: why,
                    cleanup: None,
                }),
                Err(why) => match runtime.delete(&id) {
                    Ok(()) | Err(Refusal::NoSuchBox(_)) => {
                        self.completed(key, Some(why), None, &mut step)?
                    }
                    Err(cleanup) => step.notices.push(Notice::Unknown {
                        key,
                        refusal: why,
                        cleanup: Some(cleanup),
                    }),
                },
            }
        }
        Ok(step)
    }

    fn completed(
        &self,
        key: Key,
        refusal: Option<Refusal>,
        elapsed: Option<u64>,
        step: &mut Step,
    ) -> Result<(), Error> {
        let mut state = self.lock()?;
        let State { node, rows, .. } = &mut *state;
        let result = match (refusal.is_some(), elapsed) {
            (true, _) => node.create_refused(key, rows),
            (false, Some(ns)) => node.created_with_start(key, ns, rows),
            (false, None) => node.created(key, rows),
        };
        let out = finish(&mut state, result, false)?;
        let (mut next, create) = collect(&mut state, out)?;
        if !create.is_empty() {
            state.stopped = Some(bad("create recursively requested creation"));
            return Err(bad("unexpected nested creation").into());
        }
        if let Some(why) = refusal {
            for (_, message) in &mut next.send {
                if matches!(message.msg,Msg::Refused{key:k} if k==key) {
                    message.refusal = Some(why.clone());
                }
            }
            next.notices.push(Notice::Refused {
                key,
                node: state.node.id(),
                refusal: why,
            });
        }
        step.send.extend(next.send);
        step.notices.extend(next.notices);
        Ok(())
    }

    pub fn owned(&self) -> Result<Vec<(Key, Option<NodeId>)>, Error> {
        Ok(self.lock()?.node.owned_keys().collect())
    }

    pub fn status(&self, key: Key) -> Result<Option<Status>, Error> {
        let state = self.lock()?;
        let own = state.node.owned_keys().find(|(k, _)| *k == key);
        let ran = state.node.ran_keys().find(|(k, _, _)| *k == key);
        if own.is_none() && ran.is_none() {
            return Ok(None);
        }
        Ok(Some(Status {
            key,
            node: ran
                .map(|_| state.node.id())
                .or_else(|| own.and_then(|(_, n)| n)),
            local: ran.is_some(),
            deleting: state.node.is_deleting(key),
            created: ran.is_some_and(|(_, c, _)| c) || state.node.is_created(key),
            ended: ran.is_some_and(|(_, _, e)| e) || state.node.is_ended(key),
            physical: self.physical_id(key)?,
        }))
    }

    pub fn delete(&self, key: Key) -> Result<Step, Error> {
        let _operation = self.operation()?;
        let mut state = self.lock()?;
        if state.node.owned_keys().any(|(k, _)| k == key) {
            let State { node, rows, .. } = &mut *state;
            let result = node.delete(key, rows);
            let out = finish(&mut state, result, false)?;
            let (step, effects) = collect(&mut state, out)?;
            drop(state);
            return self.drive(step, effects);
        }
        if !state.node.ran_keys().any(|(k, _, _)| k == key) {
            return Err(Refusal::NoSuchBox(self.physical_id(key)?).into());
        }
        let demand = state
            .node
            .demand(key)
            .ok_or_else(|| bad("ran demand missing"))?;
        drop(state);
        match self
            .runtimes
            .get(demand.class)?
            .delete(&self.physical_id(key)?)
        {
            Ok(()) | Err(Refusal::NoSuchBox(_)) => self.ended(key),
            Err(why) => Err(why.into()),
        }
    }

    fn ended(&self, key: Key) -> Result<Step, Error> {
        let mut state = self.lock()?;
        let State { node, rows, .. } = &mut *state;
        let result = node.end(key, rows);
        let out = finish(&mut state, result, false)?;
        let (step, create) = collect(&mut state, out)?;
        if !create.is_empty() {
            return Err(bad("end requested creation").into());
        }
        Ok(step)
    }

    pub fn poll_status(&self) -> Result<Step, Error> {
        let _operation = self.operation()?;
        let state = self.lock()?;
        let keys: Vec<_> = state
            .node
            .ran_keys()
            .filter(|(_, _, ended)| !ended)
            .map(|(key, _, _)| {
                Ok((
                    key,
                    state
                        .node
                        .demand(key)
                        .ok_or_else(|| bad("ran demand missing"))?,
                ))
            })
            .collect::<Result<_, Stop>>()?;
        drop(state);
        let mut step = Step::default();
        for (key, demand) in keys {
            match self
                .runtimes
                .get(demand.class)?
                .inspect(&self.physical_id(key)?)
            {
                Ok(info) => step.notices.push(Notice::Status { key, info }),
                Err(Refusal::NoSuchBox(_)) => {
                    let next = self.ended(key)?;
                    step.send.extend(next.send);
                    step.notices.extend(next.notices);
                }
                Err(why) => step.notices.push(Notice::Unknown {
                    key,
                    refusal: why,
                    cleanup: None,
                }),
            }
        }
        Ok(step)
    }

    /// Actual memory held by this driver's physical boxes, by runtime class. CPU/disk are not
    /// invented from caps. The caller can credit a shared pool once for all its classes.
    pub fn measured_owned_use_by_class(&self) -> Result<BTreeMap<Class, Resources>, Error> {
        let _operation = self.operation()?;
        let state = self.lock()?;
        let keys: Vec<_> = state
            .node
            .ran_keys()
            .filter(|(_, _, ended)| !ended)
            .map(|(key, _, _)| {
                Ok((
                    key,
                    state
                        .node
                        .demand(key)
                        .ok_or_else(|| bad("ran demand missing"))?,
                ))
            })
            .collect::<Result<_, Stop>>()?;
        drop(state);
        let mut resources = BTreeMap::<Class, Resources>::new();
        for (key, demand) in keys {
            match self
                .runtimes
                .get(demand.class)?
                .usage(&self.physical_id(key)?)
            {
                Ok(usage) => {
                    let owned = resources.entry(demand.class).or_default();
                    owned.mem_bytes = owned
                        .mem_bytes
                        .checked_add(usage.memory_bytes)
                        .ok_or_else(|| invalid("physical memory usage overflow"))?
                }
                Err(Refusal::NoSuchBox(_)) => {}
                Err(why) => return Err(why.into()),
            }
        }
        Ok(resources)
    }
}

fn validate(demand: &Demand, payload: &Payload) -> Result<(), Error> {
    payload.spec.check()?;
    let cpu = payload
        .spec
        .bounds
        .cpu_max_milli
        .ok_or_else(|| invalid("CPU cap required for a reserved box"))?;
    let mem = payload
        .spec
        .bounds
        .memory_max
        .ok_or_else(|| invalid("memory cap required for a reserved box"))?;
    if u64::from(cpu) > demand.need.cpu_milli || mem > demand.need.mem_bytes {
        return Err(invalid("box limits exceed placement reservation").into());
    }
    if !payload.spec.devices.is_empty() {
        return Err(invalid("the receiver selects physical devices from the demand").into());
    }
    if device_request(demand) && !matches!(&payload.spec.class, hex_api::ClassSpec::Oci(_)) {
        return Err(invalid("device placement requires a structured OCI payload").into());
    }
    if payload.start && payload.spec.class.class() != hex_api::Class::Oci {
        return Err(invalid("only OCI boxes have an init to start").into());
    }
    if demand.class != Class::Oci && payload.spec.class.class() != hex_api::Class::Oci {
        return Err(invalid("microVM placement requires an OCI guest payload").into());
    }
    let value = rows::payload_value(payload)?;
    let text = serde_json::to_string(&value).map_err(|e| bad(e.to_string()))?;
    if text.len() > hex_core::wire::MAX_MESSAGE {
        return Err(invalid("placement payload exceeds wire bound").into());
    }
    Ok(())
}

fn device_request(demand: &Demand) -> bool {
    demand.need.gpus > 0
        || demand.ask.devices()
        || demand.ask.gpu_model.is_some()
        || demand.ask.gpu_memory > 0
        || demand.ask.block_size > 0
}

fn validate_backend(payload: &Payload, runtime: &Arc<dyn Runtime>) -> Result<(), Error> {
    if !runtime.classes().contains(&payload.spec.class.class()) {
        return Err(invalid("registered runtime does not support box spec class").into());
    }
    Ok(())
}

fn finish<T>(state: &mut State, result: Result<T, Stop>, submit: bool) -> Result<T, Error> {
    result.map_err(|stop| {
        if !(submit && matches!(stop, Stop::Full { .. })) {
            state.stopped = Some(stop.clone());
        }
        Error::Core(stop)
    })
}

fn admission_refusal(why: &Stop) -> Refusal {
    match why {
        Stop::Full { what, bound } => Refusal::Exhausted {
            what,
            bound: *bound,
        },
        _ => Refusal::Broken(format!("current placement facts: {why:?}")),
    }
}

fn collect(state: &mut State, out: Vec<(NodeId, Msg)>) -> Result<Collected, Error> {
    let mut step = Step::default();
    let mut create = Vec::new();
    for (node, msg) in out {
        let payload = match msg {
            Msg::Start { key, .. } => Some(state.rows.payload("own", key)?),
            _ => None,
        };
        step.send.push((
            node,
            Envelope {
                msg,
                payload,
                refusal: None,
            },
        ));
    }
    for told in std::mem::take(&mut state.node.told) {
        match told {
            Told::Started(key, node) => step.notices.push(Notice::Started { key, node }),
            Told::Ended(key) => step.notices.push(Notice::Ended { key }),
            Told::Create(key, demand) => create.push(Effect::Create(
                key,
                demand,
                Box::new(state.rows.payload("ran", key)?),
            )),
            Told::Delete(key, demand) => create.push(Effect::Delete(key, demand)),
        }
    }
    Ok((step, create))
}

fn durable_demand(rows: &Rows, key: Key, models: &[String]) -> Result<(Demand, bool), Stop> {
    let row = rows.row(key)?;
    // The existing core durable grammar prefixes a ran demand with owner and lifecycle state.
    let (_, rest) = row.split_once(' ').ok_or_else(|| bad("ran owner"))?;
    let (state, demand) = rest.split_once(' ').ok_or_else(|| bad("ran state"))?;
    Ok((peer::decode_demand(demand, models)?, state == "ended"))
}

#[cfg(test)]
mod tests;
